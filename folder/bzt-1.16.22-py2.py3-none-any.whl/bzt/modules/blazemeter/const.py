DEDICATED_IPS = "dedicated-ips"
LOC = "locations"
LOC_WEIGHTED = "locations-weighted"
NOTE_SIZE_LIMIT = 2048