from bzt.utils import SoapUIScriptConverter     # backward compatibility
